export interface item {
  id?: string;
  name: string;
  description?: string;
  qty: number;
}
