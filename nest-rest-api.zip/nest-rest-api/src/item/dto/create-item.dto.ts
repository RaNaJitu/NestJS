export class CreateItemDto {
  readonly name: string;
  readonly description: string;
  readonly qty: number;
}
