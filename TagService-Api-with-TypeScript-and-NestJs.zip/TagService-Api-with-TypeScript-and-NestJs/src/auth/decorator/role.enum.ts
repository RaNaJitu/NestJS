export enum UserPermissions {
  READ = 'user:read',
  CREATE = 'user:create',
  UPDATE = 'user:update',
  DELETE = 'user:delete',
}
