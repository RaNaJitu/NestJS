enum Role {
  User = 'User',
  Admin = 'Admin',
}

export default Role;
