export enum tagStatus {
  ACTIVE = 'ACTIVE',
  iNACTIVE = 'INACTIVE',
}
